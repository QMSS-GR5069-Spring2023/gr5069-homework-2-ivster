# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['seatgeekpkg', 'src', 'src.seatgeekpkg']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.5.2,<2.0.0',
 'pytest>=7.2.0,<8.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'requests>=2.28.1,<3.0.0']

setup_kwargs = {
    'name': 'seatgeekpkg',
    'version': '0.1.0',
    'description': " A package that wraps around the SeatGeek API and returns recommendations of artists, popular events of a city, and cheapest tickets for an artist's concert.",
    'long_description': "# seatgeekpkg\n\n A package that wraps around the SeatGeek API and returns recommendations of artists, popular events of a city, and cheapest tickets for an artist's concert.\n\n## Installation\n\n```bash\n$ pip install seatgeekpkg\n```\n\n## Usage\n\n- TODO\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`seatgeekpkg` was created by Ivy Xin Yi Wong. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`seatgeekpkg` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n",
    'author': 'Ivy Xin Yi Wong',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
