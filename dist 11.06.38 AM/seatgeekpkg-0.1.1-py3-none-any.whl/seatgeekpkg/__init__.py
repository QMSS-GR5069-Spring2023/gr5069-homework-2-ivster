# read version from installed package
