# seatgeekpkg

 A package that wraps around the SeatGeek API and returns recommendations of artists, popular events of a city, and cheapest tickets for an artist's concert.

## Installation

```bash
$ pip install seatgeekpkg
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`seatgeekpkg` was created by Ivy Xin Yi Wong. It is licensed under the terms of the MIT license.

## Credits

`seatgeekpkg` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
